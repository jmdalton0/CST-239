# Store Front Application

# Jesse Dalton
# CST 239
# Milestone 7

[Loom Presentation](https://www.loom.com/share/1b72e0bac4014f75b19971a69bc0abee)