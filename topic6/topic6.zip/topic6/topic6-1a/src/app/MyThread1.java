package app;

public class MyThread1 extends Thread {

    public void run() {
        System.out.println("MyThread1 is running");
    }

}
